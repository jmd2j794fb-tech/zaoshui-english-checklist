const storage = require('../../utils/storage');

const EMOJI_LIST = ['💒','👘','💄','💍','📷','👶','🎂','🏨','🌸','✨','🎀','💎','🕊️','🎵','📋','🌟'];

Page({
  data: {
    shopName: '',
    shopDesc: '',
    categories: [],
    likeCount: 0,
    showCatModal: false,
    editingCatId: '',
    catFormName: '',
    catFormIcon: '📋',
    emojiList: EMOJI_LIST
  },

  onShow() {
    this.loadData();
  },

  loadData() {
    const data = storage.getData();
    this.setData({
      shopName: data.shopName || '',
      shopDesc: data.shopDesc || '',
      categories: data.categories || [],
      likeCount: storage.getLikeCount()
    });
  },

  // 店铺信息
  onShopNameInput(e) { this.setData({ shopName: e.detail.value }); },
  onShopDescInput(e) { this.setData({ shopDesc: e.detail.value }); },
  saveShop() {
    storage.updateShop(this.data.shopName, this.data.shopDesc);
    wx.showToast({ title: '已保存', icon: 'success' });
  },

  // 类目弹窗
  showAddCategory() {
    this.setData({
      showCatModal: true,
      editingCatId: '',
      catFormName: '',
      catFormIcon: '📋'
    });
  },
  editCategory(e) {
    const cat = this.data.categories.find(c => c.id === e.currentTarget.dataset.id);
    if (!cat) return;
    this.setData({
      showCatModal: true,
      editingCatId: cat.id,
      catFormName: cat.name,
      catFormIcon: cat.icon
    });
  },
  closeCatModal() { this.setData({ showCatModal: false }); },
  onCatNameInput(e) { this.setData({ catFormName: e.detail.value }); },
  pickEmoji(e) { this.setData({ catFormIcon: e.currentTarget.dataset.emoji }); },

  saveCategory() {
    const name = this.data.catFormName.trim();
    if (!name) { wx.showToast({ title: '请输入名称', icon: 'none' }); return; }
    
    if (this.data.editingCatId) {
      storage.updateCategory(this.data.editingCatId, {
        name, icon: this.data.catFormIcon
      });
    } else {
      storage.addCategory(name, this.data.catFormIcon);
    }
    this.setData({ showCatModal: false });
    this.loadData();
    wx.showToast({ title: '已保存', icon: 'success' });
  },

  deleteCategoryConfirm(e) {
    const { id, name } = e.currentTarget.dataset;
    wx.showModal({
      title: '确认删除',
      content: `删除「${name}」及其所有服务项？`,
      success: (res) => {
        if (res.confirm) {
          storage.deleteCategory(id);
          this.loadData();
          wx.showToast({ title: '已删除', icon: 'success' });
        }
      }
    });
  },
  deleteCategory() {
    if (!this.data.editingCatId) return;
    storage.deleteCategory(this.data.editingCatId);
    this.setData({ showCatModal: false });
    this.loadData();
    wx.showToast({ title: '已删除', icon: 'success' });
  },

  // 跳转编辑服务项
  goEditService(e) {
    const catId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/edit/edit?catId=${catId}`
    });
  },

  // 数据管理
  exportData() {
    const data = storage.getData();
    wx.setClipboardData({
      data: JSON.stringify(data, null, 2),
      success: () => wx.showToast({ title: '已复制到剪贴板', icon: 'success' })
    });
  },
  resetData() {
    wx.showModal({
      title: '恢复默认',
      content: '将清空所有数据并恢复预设内容，确定？',
      success: (res) => {
        if (res.confirm) {
          storage.initDefaultData();
          this.loadData();
          wx.showToast({ title: '已恢复默认', icon: 'success' });
        }
      }
    });
  },

  noop() {}
});
