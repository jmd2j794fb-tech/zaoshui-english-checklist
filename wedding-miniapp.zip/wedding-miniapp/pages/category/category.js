const storage = require('../../utils/storage');

Page({
  data: {
    catId: '',
    catName: '',
    catIcon: '',
    services: [],
    liked: {},
    showPreview: false,
    previewItem: {}
  },

  onLoad(options) {
    const { id, name } = options;
    this.setData({ catId: id, catName: name || '服务详情' });
    this.loadServices();
  },

  onShow() {
    this.loadServices();
  },

  loadServices() {
    const data = storage.getData();
    const cat = data.categories.find(c => c.id === this.data.catId);
    const services = cat ? cat.services : [];
    const icon = cat ? cat.icon : '📋';
    
    // 构建点赞状态
    const liked = {};
    services.forEach(s => {
      liked[s.id] = storage.isLiked(s.id);
    });

    this.setData({ services, catIcon: icon, liked });
  },

  toggleLike(e) {
    const svcId = e.currentTarget.dataset.id;
    const isNowLiked = storage.toggleLike(svcId);
    const liked = { ...this.data.liked };
    liked[svcId] = isNowLiked;
    this.setData({ liked });
    
    if (isNowLiked) {
      wx.showToast({ title: '已收藏 ❤️', icon: 'none', duration: 1500 });
    }
  },

  previewService(e) {
    const item = e.currentTarget.dataset.item;
    this.setData({
      showPreview: true,
      previewItem: item
    });
  },

  closePreview() {
    this.setData({ showPreview: false });
  },

  noop() {}
});
