const storage = require('../../utils/storage');

Page({
  data: {
    catId: '',
    catName: '',
    catIcon: '',
    services: [],
    showModal: false,
    editingSvcId: '',
    formName: '',
    formRegion: '',
    formDesc: ''
  },

  onLoad(options) {
    const { catId } = options;
    this.setData({ catId });
    this.loadServices();
  },

  loadServices() {
    const data = storage.getData();
    const cat = data.categories.find(c => c.id === this.data.catId);
    if (cat) {
      this.setData({
        catName: cat.name,
        catIcon: cat.icon,
        services: cat.services || []
      });
    }
  },

  // 添加
  showAddService() {
    this.setData({
      showModal: true,
      editingSvcId: '',
      formName: '',
      formRegion: '',
      formDesc: ''
    });
  },

  // 编辑
  editService(e) {
    const svcId = e.currentTarget.dataset.id;
    const svc = this.data.services.find(s => s.id === svcId);
    if (!svc) return;
    this.setData({
      showModal: true,
      editingSvcId: svcId,
      formName: svc.name,
      formRegion: svc.region,
      formDesc: svc.desc || ''
    });
  },

  closeModal() { this.setData({ showModal: false }); },
  onNameInput(e) { this.setData({ formName: e.detail.value }); },
  onRegionInput(e) { this.setData({ formRegion: e.detail.value }); },
  onDescInput(e) { this.setData({ formDesc: e.detail.value }); },

  saveService() {
    const name = this.data.formName.trim();
    if (!name) { wx.showToast({ title: '请输入名称', icon: 'none' }); return; }

    const updates = {
      name,
      region: this.data.formRegion.trim(),
      desc: this.data.formDesc.trim()
    };

    if (this.data.editingSvcId) {
      storage.updateService(this.data.catId, this.data.editingSvcId, updates);
    } else {
      storage.addService(this.data.catId, updates);
    }

    this.setData({ showModal: false });
    this.loadServices();
    wx.showToast({ title: '已保存', icon: 'success' });
  },

  deleteService(e) {
    const svcId = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认删除',
      content: '删除后不可恢复',
      success: (res) => {
        if (res.confirm) {
          storage.deleteService(this.data.catId, svcId);
          this.loadServices();
          wx.showToast({ title: '已删除', icon: 'success' });
        }
      }
    });
  },

  deleteCurrent() {
    if (!this.data.editingSvcId) return;
    storage.deleteService(this.data.catId, this.data.editingSvcId);
    this.setData({ showModal: false });
    this.loadServices();
    wx.showToast({ title: '已删除', icon: 'success' });
  },

  noop() {}
});
