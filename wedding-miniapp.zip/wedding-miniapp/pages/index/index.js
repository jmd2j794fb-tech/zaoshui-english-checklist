const storage = require('../../utils/storage');

const EMOJI_LIST = ['💒','👘','💄','💍','📷','👶','🎂','🏨','🌸','✨','🎀','💎','🕊️','🎵','📋','🌟'];
const DEFAULT_PWD = '888888';

Page({
  data: {
    shopName: '',
    shopDesc: '',
    categories: [],
    likeCount: 0,
    
    // 管理模式
    isAdmin: false,
    
    // 密码弹窗
    showLoginModal: false,
    adminPwd: '',
    
    // 店铺编辑弹窗
    showShopModal: false,
    shopFormName: '',
    shopFormDesc: '',
    
    // 类目弹窗
    showCatModal: false,
    editingCatId: '',
    catFormName: '',
    catFormIcon: '📋',
    emojiList: EMOJI_LIST
  },

  onShow() {
    this.loadData();
  },

  loadData() {
    const data = storage.getData();
    this.setData({
      shopName: data.shopName || '婚礼服务',
      shopDesc: data.shopDesc || '',
      categories: data.categories || [],
      likeCount: storage.getLikeCount()
    });
  },

  // ===== 顾客模式 =====
  goCategory(e) {
    const { id, name } = e.currentTarget.dataset;
    wx.navigateTo({ url: `/pages/category/category?id=${id}&name=${name}` });
  },

  // ===== 管理模式入口 =====
  showAdminLogin() {
    this.setData({ showLoginModal: true, adminPwd: '' });
  },
  closeLoginModal() { this.setData({ showLoginModal: false }); },
  onPwdInput(e) { this.setData({ adminPwd: e.detail.value }); },
  
  adminLogin() {
    if (this.data.adminPwd === DEFAULT_PWD) {
      this.setData({ isAdmin: true, showLoginModal: false });
      wx.showToast({ title: '管理模式已开启', icon: 'none' });
    } else {
      wx.showToast({ title: '密码错误', icon: 'none' });
    }
  },
  
  exitAdmin() {
    this.setData({ isAdmin: false });
    wx.showToast({ title: '已退出管理模式', icon: 'none' });
  },

  // 管理模式点击类目：进入编辑服务
  adminTapCategory(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({ url: `/pages/edit/edit?catId=${id}` });
  },

  // ===== 店铺编辑 =====
  editShop() {
    this.setData({
      showShopModal: true,
      shopFormName: this.data.shopName,
      shopFormDesc: this.data.shopDesc
    });
  },
  closeShopModal() { this.setData({ showShopModal: false }); },
  onShopNameInput(e) { this.setData({ shopFormName: e.detail.value }); },
  onShopDescInput(e) { this.setData({ shopFormDesc: e.detail.value }); },
  saveShop() {
    storage.updateShop(this.data.shopFormName, this.data.shopFormDesc);
    this.setData({ showShopModal: false });
    this.loadData();
    wx.showToast({ title: '已保存', icon: 'success' });
  },

  // ===== 类目管理 =====
  showAddCategory() {
    this.setData({ showCatModal: true, editingCatId: '', catFormName: '', catFormIcon: '📋' });
  },
  editCategory(e) {
    const cat = this.data.categories.find(c => c.id === e.currentTarget.dataset.id);
    if (!cat) return;
    this.setData({
      showCatModal: true, editingCatId: cat.id,
      catFormName: cat.name, catFormIcon: cat.icon
    });
  },
  closeCatModal() { this.setData({ showCatModal: false }); },
  onCatNameInput(e) { this.setData({ catFormName: e.detail.value }); },
  pickEmoji(e) { this.setData({ catFormIcon: e.currentTarget.dataset.emoji }); },

  saveCategory() {
    const name = this.data.catFormName.trim();
    if (!name) { wx.showToast({ title: '请输入名称', icon: 'none' }); return; }
    if (this.data.editingCatId) {
      storage.updateCategory(this.data.editingCatId, { name, icon: this.data.catFormIcon });
    } else {
      storage.addCategory(name, this.data.catFormIcon);
    }
    this.setData({ showCatModal: false });
    this.loadData();
    wx.showToast({ title: '已保存', icon: 'success' });
  },

  deleteCategoryConfirm(e) {
    const { id, name } = e.currentTarget.dataset;
    wx.showModal({
      title: '确认删除', content: `删除「${name}」及其所有服务项？`,
      success: (res) => {
        if (res.confirm) {
          storage.deleteCategory(id);
          this.loadData();
          wx.showToast({ title: '已删除', icon: 'success' });
        }
      }
    });
  },
  deleteCategory() {
    if (!this.data.editingCatId) return;
    storage.deleteCategory(this.data.editingCatId);
    this.setData({ showCatModal: false });
    this.loadData();
    wx.showToast({ title: '已删除', icon: 'success' });
  },

  // 跳转编辑服务项
  goEditService(e) {
    const catId = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/edit/edit?catId=${catId}` });
  },

  // 统计
  showStats() {
    wx.showModal({
      title: '❤️ 收藏统计',
      content: `顾客共收藏了 ${this.data.likeCount} 次`,
      showCancel: false
    });
  },

  noop() {}
});
