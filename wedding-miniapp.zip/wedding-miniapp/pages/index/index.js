const storage = require('../../utils/storage');

Page({
  data: {
    shopName: '',
    shopDesc: '',
    categories: []
  },

  onShow() {
    this.loadData();
  },

  loadData() {
    const data = storage.getData();
    this.setData({
      shopName: data.shopName || '婚礼服务',
      shopDesc: data.shopDesc || '',
      categories: data.categories || []
    });
  },

  goCategory(e) {
    const { id, name } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/category/category?id=${id}&name=${name}`
    });
  }
});
