const STORAGE_KEY = 'wedding_services';
const ADMIN_KEY = 'wedding_admin';

// 默认数据
const DEFAULT_DATA = {
  shopName: 'Bonanzayy888',
  shopDesc: '婚礼一站式服务 · 用心记录每一场婚礼',
  categories: [
    {
      id: 'c_001',
      name: '婚礼',
      icon: '💒',
      order: 0,
      services: [
        { id: 's_001', name: '沃顿薇嫁衣', region: '青秀民政局、西乡塘民政局', desc: '', createdAt: Date.now() },
        { id: 's_002', name: '红林大酒店', region: '南宁', desc: '', createdAt: Date.now() },
        { id: 's_003', name: '会展豪生酒店', region: '南宁', desc: '', createdAt: Date.now() },
        { id: 's_004', name: '远梦酒店', region: '南宁', desc: '', createdAt: Date.now() }
      ]
    },
    {
      id: 'c_002',
      name: '晨袍',
      icon: '👘',
      order: 1,
      services: [
        { id: 's_005', name: '新娘晨袍写真', region: '广东罗定、南宁', desc: '', createdAt: Date.now() },
        { id: 's_006', name: '闺蜜晨袍合拍', region: '青秀区', desc: '', createdAt: Date.now() }
      ]
    },
    {
      id: 'c_003',
      name: '跟妆',
      icon: '💄',
      order: 2,
      services: [
        { id: 's_007', name: '新娘跟妆全天', region: '南宁、玉林', desc: '', createdAt: Date.now() },
        { id: 's_008', name: '新郎妆发造型', region: '南宁', desc: '', createdAt: Date.now() }
      ]
    },
    {
      id: 'c_004',
      name: '领证',
      icon: '💍',
      order: 3,
      services: [
        { id: 's_009', name: '领证跟拍', region: '青秀民政局、西乡塘民政局', desc: '', createdAt: Date.now() },
        { id: 's_010', name: '领证妆造', region: '南宁各民政局', desc: '', createdAt: Date.now() }
      ]
    },
    {
      id: 'c_005',
      name: '结婚跟拍',
      icon: '📷',
      order: 4,
      services: [
        { id: 's_011', name: '婚礼全程跟拍', region: '南宁、玉林、广东', desc: '', createdAt: Date.now() },
        { id: 's_012', name: '婚礼快剪', region: '南宁', desc: '', createdAt: Date.now() }
      ]
    },
    {
      id: 'c_006',
      name: '宝宝宴上门拍',
      icon: '👶',
      order: 5,
      services: [
        { id: 's_013', name: '宝宝满月上门拍', region: '南宁', desc: '', createdAt: Date.now() },
        { id: 's_014', name: '百日照上门', region: '南宁、玉林', desc: '', createdAt: Date.now() }
      ]
    },
    {
      id: 'c_007',
      name: '周岁宴',
      icon: '🎂',
      order: 6,
      services: [
        { id: 's_015', name: '周岁宴跟拍', region: '南宁', desc: '', createdAt: Date.now() },
        { id: 's_016', name: '周岁宴布置+拍摄', region: '南宁、玉林', desc: '', createdAt: Date.now() }
      ]
    },
    {
      id: 'c_008',
      name: '玉林永朝燕喜',
      icon: '🏨',
      order: 7,
      services: [
        { id: 's_017', name: '婚宴全套服务', region: '玉林', desc: '', createdAt: Date.now() }
      ]
    }
  ],
  // 点赞数据：{ serviceId: count }
  likes: {}
};

function getData() {
  try {
    const data = wx.getStorageSync(STORAGE_KEY);
    if (data) return JSON.parse(data);
  } catch(e) {}
  return { shopName: '', shopDesc: '', categories: [] };
}

function saveData(data) {
  wx.setStorageSync(STORAGE_KEY, JSON.stringify(data));
}

function initDefaultData() {
  saveData(DEFAULT_DATA);
}

function genId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 6);
}

// 类目操作
function addCategory(name, icon) {
  const data = getData();
  const category = {
    id: genId(),
    name: name,
    icon: icon || '📋',
    order: data.categories.length,
    services: []
  };
  data.categories.push(category);
  saveData(data);
  return category;
}

function updateCategory(catId, updates) {
  const data = getData();
  const cat = data.categories.find(c => c.id === catId);
  if (!cat) return false;
  Object.assign(cat, updates);
  saveData(data);
  return true;
}

function deleteCategory(catId) {
  const data = getData();
  data.categories = data.categories.filter(c => c.id !== catId);
  saveData(data);
}

function reorderCategories(orderedIds) {
  const data = getData();
  orderedIds.forEach((id, idx) => {
    const cat = data.categories.find(c => c.id === id);
    if (cat) cat.order = idx;
  });
  data.categories.sort((a, b) => a.order - b.order);
  saveData(data);
}

// 服务项操作
function addService(catId, service) {
  const data = getData();
  const cat = data.categories.find(c => c.id === catId);
  if (!cat) return null;
  const newService = {
    id: genId(),
    name: service.name || '',
    region: service.region || '',
    desc: service.desc || '',
    createdAt: Date.now()
  };
  cat.services.push(newService);
  saveData(data);
  return newService;
}

function updateService(catId, svcId, updates) {
  const data = getData();
  const cat = data.categories.find(c => c.id === catId);
  if (!cat) return false;
  const svc = cat.services.find(s => s.id === svcId);
  if (!svc) return false;
  Object.assign(svc, updates);
  saveData(data);
  return true;
}

function deleteService(catId, svcId) {
  const data = getData();
  const cat = data.categories.find(c => c.id === catId);
  if (!cat) return;
  cat.services = cat.services.filter(s => s.id !== svcId);
  saveData(data);
}

// 店铺信息
function updateShop(name, desc) {
  const data = getData();
  data.shopName = name;
  data.shopDesc = desc;
  saveData(data);
}

// 点赞
function toggleLike(svcId) {
  const data = getData();
  if (!data.likes) data.likes = {};
  if (data.likes[svcId]) {
    delete data.likes[svcId];
    saveData(data);
    return false;
  } else {
    data.likes[svcId] = Date.now();
    saveData(data);
    return true;
  }
}

function isLiked(svcId) {
  const data = getData();
  return !!(data.likes && data.likes[svcId]);
}

function getLikeCount() {
  const data = getData();
  return data.likes ? Object.keys(data.likes).length : 0;
}

module.exports = {
  getData, saveData, initDefaultData, genId,
  addCategory, updateCategory, deleteCategory, reorderCategories,
  addService, updateService, deleteService, updateShop,
  toggleLike, isLiked, getLikeCount
};
