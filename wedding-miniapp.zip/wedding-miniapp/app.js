App({
  onLaunch() {
    // 初始化默认数据
    const storage = require('./utils/storage');
    const data = storage.getData();
    if (!data.categories || data.categories.length === 0) {
      storage.initDefaultData();
    }
  }
});
